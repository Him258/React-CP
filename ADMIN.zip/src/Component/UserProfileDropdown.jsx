import React, { useState } from 'react';

const UserProfileDropdown = () => {
    const [dropdownOpen, setDropdownOpen] = useState(false);

    return (
        <div className="relative ">
            <div className='flex items-center gap-2'>
                <div className='h-10 w-10 rounded-full border-2 border-black overflow-hidde relative after:absolute after:w-3 after:rounded-full after:h-3 after:bg-green-400 after:top-0 after:-right-1'>
                    <img
                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSs9iOHC-Yk3H9lPV3jzY0lUUlNGpMCYGmaxw&s"
                        alt="User"
                        className=" w-full h-full object-cover rounded-full "
                        
                    />
                </div>
                <i onClick={() => setDropdownOpen(!dropdownOpen)} class="ri-arrow-down-s-line text-3xl cursor-pointer"></i>
            </div>
            {dropdownOpen && (
                <div className="absolute right-0 mt-2 py-2 w-48 bg-white border rounded shadow-xl cursor-default">
                    <div className='flex items-center gap-2 px-4 py-2'>
                        <div className='h-10 w-10 rounded-full border-2 border-black overflow-hidden'>
                            <img
                                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSs9iOHC-Yk3H9lPV3jzY0lUUlNGpMCYGmaxw&s"
                                alt="User"
                                className=" w-full h-full object-cover cursor-pointer"
                                onClick={() => setDropdownOpen(!dropdownOpen)}
                            />
                        </div>
                        <div>
                            <h1 className='text-black font-bold'>John Doe</h1>
                            <p className='text-gray-800 text-sm '>UI/UX Designer</p>
                        </div>
                    </div>
                    <a href="#profile" className="block px-4 py-2 text-gray-800 hover:bg-gray-200">
                    <i class="ri-user-6-fill"></i>   Profile
                    </a>
                    <a href="#account-settings" className="block px-4 py-2 text-gray-800 hover:bg-gray-200">
                    <i class="ri-settings-2-fill"></i> Account Setting
                    </a>
                    <a href="#logout" className="block px-4 py-2 text-red-600 hover:bg-red-200">
                    <i class="ri-logout-circle-r-line"></i>  Logout
                    </a>
                </div>
            )}
        </div>
    );
};

export default UserProfileDropdown;
