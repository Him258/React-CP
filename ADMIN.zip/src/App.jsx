import React from 'react'
import 'remixicon/fonts/remixicon.css'
import DashboardLayout from './Component/DashboardLayout'

const App = () => {
  return (
    <div>
      <DashboardLayout/>
    </div>
  )
}

export default App