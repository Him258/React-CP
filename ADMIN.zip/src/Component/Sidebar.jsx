import React, { useState } from 'react';
import logo from '../assets/logo.png';
import { RiFunctionLine, RiSchoolLine, RiGroupLine, RiExchangeDollarLine, RiBook2Line } from "react-icons/ri";

const Sidebar = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const handleTabClick = (index) => {
    setActiveTab(index);
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div>
      {/* Mobile Logo and Sidebar Toggle */}
      <div className='md:hidden p-2'>
        <div className='w-14 h-14' onClick={toggleSidebar}>
          <img src={logo} alt="logo" className='w-full h-full object-cover cursor-pointer' />
        </div>
      </div>

      {/* Sidebar Container */}
      <div className={`fixed md:static top-0 left-0 transform bg-white ${isSidebarOpen ? 'translate-x-0' : '-translate-x-[120%]'} md:translate-x-0 transition-transform duration-300 ease-in-out z-50 md:z-auto`}>
        {/* Sidebar Header with Logo and Search Bar */}
        <div className='w-full h-[60px] border-r border-b border-black/40 flex '>
          <div className='w-20 h-full border-r border-black/40 flex items-center justify-center'>
            <div className='w-14 h-14'>
              <img src={logo} alt="logo" className='w-full h-full object-cover' />
            </div>
          </div>
          <div className='flex items-center justify-center md:w-72 w-52 p-5 relative '>
            <input type="text" placeholder='Search' className='w-full outline-none rounded-md py-2 px-5 border border-black/40' />
          </div>
          <div onClick={toggleSidebar} className='w-10 h-10 bg-gray-100 flex items-center justify-center absolute md:hidden top-0 -right-10 text-gray-400'>
          <i class="ri-close-circle-line text-3xl"></i>
          </div>
        </div>

        {/* Sidebar Content */}
        <div className='flex'>
          {/* Sidebar Navigation */}
          <div style={{ height: 'calc(100vh - 60px)' }} className="w-20 bg-white shadow-md border-r border-black/40">
            <div className='w-full flex flex-col gap-5 items-center mt-8'>
              <button
                className={`w-12 h-12 bg-white rounded-md flex items-center justify-center ${activeTab === 0 ? 'bg-gray-200' : ''}`}
                onClick={() => handleTabClick(0)}
              >
                <RiFunctionLine className="text-3xl" />
              </button>
              <button
                className={`w-12 h-12 bg-white rounded-md flex items-center justify-center ${activeTab === 1 ? 'bg-gray-200' : ''}`}
                onClick={() => handleTabClick(1)}
              >
                <RiSchoolLine className="text-3xl" />
              </button>
              <button
                className={`w-12 h-12 bg-white rounded-md flex items-center justify-center ${activeTab === 2 ? 'bg-gray-200' : ''}`}
                onClick={() => handleTabClick(2)}
              >
                <RiGroupLine className="text-3xl" />
              </button>
              <button
                className={`w-12 h-12 bg-white rounded-md flex items-center justify-center ${activeTab === 3 ? 'bg-gray-200' : ''}`}
                onClick={() => handleTabClick(3)}
              >
                <RiExchangeDollarLine className="text-3xl" />
              </button>
              <button
                className={`w-12 h-12 bg-white rounded-md flex items-center justify-center ${activeTab === 4 ? 'bg-gray-200' : ''}`}
                onClick={() => handleTabClick(4)}
              >
                <RiBook2Line className="text-3xl" />
              </button>
            </div>
          </div>

          {/* Sidebar Details based on Active Tab */}
          <div style={{ height: 'calc(100vh - 60px)' }} className="md:w-72 w-52 bg-white border-r border-black/40 p-4">
            <h1>My Options</h1>
            <div className='w-full flex flex-col gap-2 items-center mt-8'>
              {activeTab === 0 && (
                <>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <RiFunctionLine className="text-xl" /> Dashboard
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-feedback-line text-xl"></i> Feedbacks
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Leaves
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Attendance
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Daily TimeSheet
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Work Log
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Reimbursements
                  </div>
                  <div className='w-full h-1 bg-gray-200 my-4'></div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Work Log
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Reimbursements
                  </div>
                </>
              )}
              {activeTab === 1 && (
                <>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <RiFunctionLine className="text-xl" /> Dashboard
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Leaves
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Daily TimeSheet
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Work Log
                  </div>
                  <div className='w-full h-1 bg-gray-200 my-4'></div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Work Log
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Reimbursements
                  </div>
                </>
              )}
              {activeTab === 2 && (
                <>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <RiFunctionLine className="text-xl" /> Dashboard
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-feedback-line text-xl"></i> Feedbacks
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Leaves
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Daily TimeSheet
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Reimbursements
                  </div>
                </>
              )}
              {activeTab === 3 && (
                <>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <RiFunctionLine className="text-xl" /> Dashboard
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-feedback-line text-xl"></i> Feedbacks
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Leaves
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Daily TimeSheet
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Reimbursements
                  </div>
                </>
              )}
              {activeTab === 4 && (
                <>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <RiFunctionLine className="text-xl" /> Dashboard
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-feedback-line text-xl"></i> Feedbacks
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Leaves
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Daily TimeSheet
                  </div>
                  <div className='w-full py-1 px-5 rounded-md hover:bg-gray-200 flex gap-2 items-center'>
                    <i className="ri-vip-crown-line text-xl"></i> Reimbursements
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
