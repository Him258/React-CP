import React from 'react';
import UserProfileDropdown from './UserProfileDropdown'
const Navbar = () => {
  return (
    <div className="flex justify-between items-center p-4 bg-white">
      <div className="flex items-center justify-end  w-full">
        <UserProfileDropdown />
      </div>
    </div>
  );
};

export default Navbar;
